This folder contains the HTML templates
