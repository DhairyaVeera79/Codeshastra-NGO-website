This folder contains the source code for the python Flask-based backend
