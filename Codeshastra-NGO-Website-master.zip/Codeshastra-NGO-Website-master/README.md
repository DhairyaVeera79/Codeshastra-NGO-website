# Codeshastra-NGO-Website
A website which allows users to inform NGOs about needy people. The website also allows viewing of profiles of registered NGOs and needy people. Users can filter and search for NGOs in their locality. 

Created for a 7hr Hackathon
