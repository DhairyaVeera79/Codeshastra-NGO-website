This folder contains the CSS files
